package com.zybooks.travelapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TripAdapter extends RecyclerView.Adapter<TripAdapter.TripViewHolder> {

    private List<DatabaseHelper.Trip> tripList;
    private OnItemClickListener listener;

    // Constructor
    public TripAdapter(List<DatabaseHelper.Trip> tripList) {
        this.tripList = tripList;
    }

    // Interface for click events
    public interface OnItemClickListener {
        void onItemClick(DatabaseHelper.Trip trip);
    }

    // Method to set the click listener
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public TripViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.trip_item, parent, false);
        return new TripViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TripViewHolder holder, int position) {
        DatabaseHelper.Trip trip = tripList.get(position);
        holder.tripNameTextView.setText(trip.getTripName());
        holder.tripDateTextView.setText(trip.getTripDate());
        holder.tripDescriptionTextView.setText(trip.getTripId());
    }

    @Override
    public int getItemCount() {
        return tripList.size();
    }

    // ViewHolder class
    public class TripViewHolder extends RecyclerView.ViewHolder {
        public TextView tripNameTextView;
        public TextView tripDateTextView;
        public TextView tripDescriptionTextView;

        public TripViewHolder(View itemView) {
            super(itemView);
            tripNameTextView = itemView.findViewById(R.id.tripNameTextView);
            tripDateTextView = itemView.findViewById(R.id.tripDateTextView);
            tripDescriptionTextView = itemView.findViewById(R.id.tripDescriptionTextView);

            // Set click listener for the item
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION && listener != null) {
                        listener.onItemClick(tripList.get(position));
                    }
                }
            });
        }
    }
}