package com.zybooks.travelapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Information
    private static final String DATABASE_NAME = "event_planner.db";
    private static final int DATABASE_VERSION = 1;

    // User Credentials Table
    private static final String TABLE_USERS = "users";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";

    // Grid Data (Trip Events) Table
    private static final String TABLE_TRIPS = "trips";
    private static final String KEY_TRIP_ID = "trip_id";
    private static final String KEY_TRIP_NAME = "trip_name";
    private static final String KEY_TRIP_DATE = "trip_date";
    private static final String KEY_TRIP_DESCRIPTION = "trip_description";
    private static final String KEY_USER_ID_FK = "user_id_fk";

    // SQL statements for creating tables
    private static final String CREATE_TABLE_USERS =
            "CREATE TABLE " + TABLE_USERS + "(" +
                    KEY_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    KEY_USERNAME + " TEXT UNIQUE," +
                    KEY_PASSWORD + " TEXT" +
                    ")";

    private static final String CREATE_TABLE_TRIPS =
            "CREATE TABLE " + TABLE_TRIPS + "(" +
                    KEY_TRIP_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    KEY_TRIP_NAME + " TEXT," +
                    KEY_TRIP_DATE + " TEXT," +
                    KEY_TRIP_DESCRIPTION + " TEXT," +
                    KEY_USER_ID_FK + " INTEGER," +
                    "FOREIGN KEY(" + KEY_USER_ID_FK + ") REFERENCES " + TABLE_USERS + "(" + KEY_USER_ID + ")" +
                    ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_TRIPS);
        Log.d("DatabaseHelper", "Tables created.");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database schema changes here
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRIPS);
        onCreate(db);
    }

    // --- User Credentials CRUD Operations ---

    public long addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_USERNAME, username);
        values.put(KEY_PASSWORD, password);
        long id = db.insert(TABLE_USERS, null, values);
        db.close();
        return id;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(TABLE_USERS,
                    new String[]{KEY_USER_ID},
                    KEY_USERNAME + "=? AND " + KEY_PASSWORD + "=?",
                    new String[]{username, password},
                    null, null, null);
            return cursor.moveToFirst();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
    }

    public int updateUserPassword(int userId, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_PASSWORD, newPassword);
        int rowsAffected = db.update(TABLE_USERS, values, KEY_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        db.close();
        return rowsAffected;
    }

    public int deleteUser(int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_USERS, KEY_USER_ID + " = ?", new String[]{String.valueOf(userId)});
        db.close();
        return rowsAffected;
    }

    // --- Trip Events CRUD Operations ---

    public long addTrip(String tripName, String tripDate, String tripDescription, long userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_TRIP_NAME, tripName);
        values.put(KEY_TRIP_DATE, tripDate);
        values.put(KEY_TRIP_DESCRIPTION, tripDescription);
        values.put(KEY_USER_ID_FK, userId);
        long id = db.insert(TABLE_TRIPS, null, values);
        db.close();
        return id;
    }

    public List<Trip> getAllTrips(long userId) {
        List<Trip> tripList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            cursor = db.query(TABLE_TRIPS, null, KEY_USER_ID_FK + "=?", new String[]{String.valueOf(userId)}, null, null, null);

            if (cursor.moveToFirst()) {
                do {
                    Trip trip = new Trip();
                    trip.setTripId(cursor.getInt(cursor.getColumnIndexOrThrow(KEY_TRIP_ID)));
                    trip.setTripName(cursor.getString(cursor.getColumnIndexOrThrow(KEY_TRIP_NAME)));
                    trip.setTripDate(cursor.getString(cursor.getColumnIndexOrThrow(KEY_TRIP_DATE)));
                    trip.setTripDescription(cursor.getString(cursor.getColumnIndexOrThrow(KEY_TRIP_DESCRIPTION)));
                    trip.setUserId(cursor.getInt(cursor.getColumnIndexOrThrow(KEY_USER_ID_FK)));
                    tripList.add(trip);
                } while (cursor.moveToNext());
            }
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
        return tripList;
    }

    public int updateTrip(Trip trip) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_TRIP_NAME, trip.getTripName());
        values.put(KEY_TRIP_DATE, trip.getTripDate());
        values.put(KEY_TRIP_DESCRIPTION, trip.getTripDescription());
        values.put(KEY_USER_ID_FK, trip.getUserId());
        int rowsAffected = db.update(TABLE_TRIPS, values, KEY_TRIP_ID + " = ?", new String[]{String.valueOf(trip.getTripId())});
        db.close();
        return rowsAffected;
    }

    public int deleteTrip(int tripId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_TRIPS, KEY_TRIP_ID + " = ?", new String[]{String.valueOf(tripId)});
        db.close();
        return rowsAffected;
    }

    // Trip class

    public static class Trip {
        private int tripId;
        private String tripName;
        private String tripDate;
        private String tripDescription;
        private int userId;

        public Trip() {
        }

        public int getTripId() {
            return tripId;
        }

        public void setTripId(int tripId) {
            this.tripId = tripId;
        }

        public String getTripName() {
            return tripName;
        }

        public void setTripName(String tripName) {
            this.tripName = tripName;
        }

        public String getTripDate() {
            return tripDate;
        }

        public void setTripDate(String tripDate) {
            this.tripDate = tripDate;
        }