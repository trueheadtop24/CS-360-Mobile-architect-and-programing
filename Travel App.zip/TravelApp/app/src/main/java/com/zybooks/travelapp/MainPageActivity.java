package com.zybooks.travelapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class MainPageActivity extends AppCompatActivity implements TripAdapter.OnItemClickListener {

    private RecyclerView recyclerView;
    private TripAdapter tripAdapter;
    private DatabaseHelper dbHelper;
    private Button buttonAddTask;
    private List<DatabaseHelper.Trip> trips;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);

        dbHelper = new DatabaseHelper(this);
        buttonAddTask = findViewById(R.id.buttonAddTask);
        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Retrieve and display trips for the current user
        displayTrips();

        buttonAddTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAddTripDialog();
            }
        });
    }

    private void displayTrips() {
        trips = dbHelper.getAllTrips(1); //get trips from the database
        tripAdapter = new TripAdapter(trips);
        tripAdapter.setOnItemClickListener(this);
        recyclerView.setAdapter(tripAdapter);
    }

    private void showAddTripDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_trip, null);
        final EditText tripNameEditText = dialogView.findViewById(R.id.editTripName);
        final EditText tripDateEditText = dialogView.findViewById(R.id.editTripDate);
        final EditText tripDescriptionEditText = dialogView.findViewById(R.id.editTripDescription);

        builder.setView(dialogView)
                .setTitle("Add New Task")
                .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String tripName = tripNameEditText.getText().toString();
                        String tripDate = tripDateEditText.getText().toString();
                        String tripDescription = tripDescriptionEditText.getText().toString();

                        // Create a new trip object
                        DatabaseHelper.Trip newTrip = new DatabaseHelper.Trip();
                        newTrip.setTripName(tripName);
                        newTrip.setTripDate(tripDate);
                        newTrip.setTripDescription(tripDescription);

                        long id = dbHelper.addTrip(tripName, tripDate, tripDescription, 1);
                        if (id > 0) {
                            Toast.makeText(MainPageActivity.this, "Trip added", Toast.LENGTH_SHORT).show();
                            displayTrips();
                        } else {
                            Toast.makeText(MainPageActivity.this, "Error adding trip", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    private void showEditTripDialog(final DatabaseHelper.Trip trip) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_trip, null);
        final EditText tripNameEditText = dialogView.findViewById(R.id.editTripName);
        final EditText tripDateEditText = dialogView.findViewById(R.id.editTripDate);
        final EditText tripDescriptionEditText = dialogView.findViewById(R.id.editTripDescription);

        // Pre-fill with existing data
        tripNameEditText.setText(trip.getTripName());
        tripDateEditText.setText(trip.getTripDate());
        tripDescriptionEditText.setText(trip.getTripDescription());

        builder.setView(dialogView)
                .setTitle("Edit Task")
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String tripName = tripNameEditText.getText().toString();
                        String tripDate = tripDateEditText.getText().toString();
                        String tripDescription = tripDescriptionEditText.getText().toString();

                        trip.setTripName(tripName);
                        trip.setTripDate(tripDate);
                        trip.setTripDescription(tripDescription);

                        int rowsAffected = dbHelper.updateTrip(trip);
                        if (rowsAffected > 0) {
                            Toast.makeText(MainPageActivity.this, "Trip updated", Toast.LENGTH_SHORT).show();
                            displayTrips();
                        } else {
                            Toast.makeText(MainPageActivity.this, "Error updating trip", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    @Override
    public void onItemClick(DatabaseHelper.Trip trip) {
        showEditTripDialog(trip);
    }
}