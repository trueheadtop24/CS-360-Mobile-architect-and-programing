package com.zybooks.travelapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CreateAccount extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button createAccountButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_account);

        // Initialize database helper
        dbHelper = new DatabaseHelper(this);

        // Initialize UI elements
        usernameEditText = findViewById(R.id.editCreateUsername);
        passwordEditText = findViewById(R.id.editCreatePassword);
        createAccountButton = findViewById(R.id.buttonCreateAccount);

        //set padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Set click listener for create account button
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAccount();
            }
        });
    }

    private void createAccount() {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Check for empty fields
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add user to the database
        long userId = dbHelper.addUser(username, password);

        if (userId != -1) {
            // Account created successfully
            Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();

            // Navigate to the login page or main activity
            Intent intent = new Intent(CreateAccount.this, MainActivity.class);
            startActivity(intent);
            finish(); // Close the create account activity
        } else {
            // Error creating account
            Toast.makeText(this, "Error creating account", Toast.LENGTH_SHORT).show();
        }
    }
}