package com.zybooks.a3_2assignmentreginaldtrue;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nameText;
    private TextView textGreeting;
    private Button buttonSayHello;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameText = findViewById(R.id.nameText);
        textGreeting = findViewById(R.id.textGreeting);
        buttonSayHello = findViewById(R.id.buttonSayHello);

        // Disable button at start
        buttonSayHello.setEnabled(false);

        // Listen for changes in the name field
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Not needed for this case, but you might want it later
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Enable button if text is not empty
                buttonSayHello.setEnabled(!s.toString().trim().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Not needed for this case, but you might want it later
            }
        });
    }

    // Called when the button is clicked
    public void SayHello(View view) {
        String name = nameText.getText().toString().trim();
        if (!name.isEmpty()) {
            textGreeting.setText("Hello " + name + "!");
        }
    }
}